# 04. Hoja de Ruta de Formalización en Chile (SpA)

> ⚠️ **REGLA DE ORO DE ETAPA TEMPRANA:**  
> **NO formalices empresa hoy.** En la fase actual de validación y testeo de pauta con $10-$50 USD operas como **Persona Natural** con tu tarjeta propia. Constituir SpA, pagar oficina virtual e ir al SII antes de validar el dolor cuesta más de $100.000 CLP y es una trampa de procrastinación.  
> **Este documento es tu protocolo para cuando ganes Corfo o alcances tracción sostenida de clientes.**

---

## 1. El Semáforo de Cuándo Formalizar

- 🟢 **Fase 1: Validación Pura (HOY):** Persona Natural. Pauta con tarjeta propia. Landing con lista de espera o WhatsApp. Costo burocracia: **$0 CLP**. Corfo Semilla Inicia permite postular como Persona Natural.
- 🟡 **Fase 2: Primera Fricción de Cobro:** Los primeros 3 a 5 clientes pagan. Cobro por transferencia/Stripe. Si un cliente B2B exige respaldo tributario, emites **Boleta de Honorarios** personal por consultoría/desarrollo.
- 🔴 **Fase 3: Formalización SpA (ÉXITO):** Adjudicaste subsidio Corfo ($15M+) o tienes facturación mensual recurrente. Los costos de constitución y oficina virtual se pueden rendir con el subsidio de Corfo.

---

## 2. Checklist Operativo para Fase 3 (Cuando Corfo o los Clientes lo Exijan)

- [ ] **Constitución:** Crear la SpA mediante el portal oficial *Tu Empresa en un Día* (costo de trámite: $0 CLP + firma electrónica avanzada ~ $2.000 CLP).
- [ ] **Domicilio Tributario / Oficina Virtual:** Contratar servicio de oficina virtual ($10.000 a $20.000 CLP/mes) para obtener patente municipal y acreditar domicilio ante SII.
- [ ] **RUT y Giro:** Obtención de RUT en SII e inicio de actividades en primera categoría (giros tecnológicos / desarrollo de software).
- [ ] **Cuenta Bancaria para Empresas:** Apertura de cuenta corriente o cuenta vista para startups (ej. Banco de Chile, Bci o Banco Estado) para recibir aportes y fondos Corfo de forma separada al patrimonio personal.
- [ ] **Facturación / Rendición:** Registro para emisión de facturas y boletas electrónicas en SII.
- [ ] **Pauta y Publicidad:** Registrar la tarjeta de la empresa en Meta Ads / Google Ads para rendir los gastos de pauta como gasto operacional o subvencionable.
